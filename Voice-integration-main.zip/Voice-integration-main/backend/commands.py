import re
from typing import Dict
from word2number import w2n

inventory: Dict[str, int] = {}
egg_omelet_steps = [
    "Crack 3 eggs into a bowl and whisk them with a fork until well blended. This takes about 30 seconds.",
    "Add a pinch of salt and pepper to the eggs for seasoning.",
    "Heat a non-stick skillet over medium heat and melt 1 tablespoon of butter. This takes about 1 minute.",
    "Pour the eggs into the skillet and let them cook undisturbed for about 2 minutes until the edges start to set.",
    "Use a spatula to gently lift the edges, allowing uncooked egg to flow underneath. Cook for another 1–2 minutes.",
    "When the omelet is mostly set but slightly runny on top, add fillings like cheese or ham if desired.",
    "Fold the omelet in half and cook for another 30 seconds to 1 minute until fully set.",
    "Slide the omelet onto a plate and serve immediately."
]
current_step = -1


def process_voice_command(text: str):
    global current_step
    lower = text.lower().strip()

    if "help" in lower or "what can you do" in lower:
        return reply("SHOW_HELP", {}, """Here are some things you can ask me to do:

Recipe Commands:
• "Start an egg omelet"
• "Next or previous step"
• "Stop recipe"

Inventory Commands:
• "Add 5 apples"
• "Use 2 apples"
• "How many apples do I have?"
• "Show inventory"
""")

    if "start" in lower and ("egg" in lower or "omelet" in lower):
        current_step = 0
        return reply("START_RECIPE", {"recipe_name": "egg_omelet"}, egg_omelet_steps[current_step])

    if "stop recipe" in lower or "exit recipe" in lower or "end recipe" in lower:
        current_step = -1
        return reply("STOP_RECIPE", {}, "Okay, exiting the recipe.")

    if "next step" in lower:
        if current_step < len(egg_omelet_steps) - 1:
            current_step += 1
            return reply("NAVIGATE_RECIPE", {"direction": "next"}, egg_omelet_steps[current_step])
        return reply("NAVIGATE_RECIPE", {"direction": "next"}, "You're at the last step.")

    if "previous step" in lower or "go back" in lower:
        if current_step > 0:
            current_step -= 1
            return reply("NAVIGATE_RECIPE", {"direction": "previous"},
                         f"Okay, going back. The previous step was: {egg_omelet_steps[current_step]}")
        return reply("NAVIGATE_RECIPE", {"direction": "previous"}, "You're at the first step.")

    if "show inventory" in lower or "what's in my inventory" in lower:
        if not inventory:
            return reply("SHOW_INVENTORY", {}, "Your inventory is empty.")
        lines = [f"• {qty} {pluralize(qty, item)}" for item, qty in inventory.items()]
        return reply("SHOW_INVENTORY", {}, "Here's what's in your inventory:\n" + "\n".join(lines))

    if match := re.match(r"add ([\w-]+)? ?(.+)", lower):
        qty_raw = match.group(1) or "1"
        try:
            qty = int(qty_raw)
        except ValueError:
            try:
                qty = w2n.word_to_num(qty_raw)
            except:
                qty = 1
        item = singularize(match.group(2))
        inventory[item] = inventory.get(item, 0) + qty
        return reply("ADD_TO_INVENTORY", {"item": item, "quantity": qty},
                     f"Okay, I've added {qty} {pluralize(qty, item)} to your inventory.")

    if match := re.match(r"use ([\w-]+)? ?(.+)", lower):
        qty_raw = match.group(1) or "1"
        try:
            qty = int(qty_raw)
        except ValueError:
            try:
                qty = w2n.word_to_num(qty_raw)
            except:
                qty = 1
        item = singularize(match.group(2))
        current = inventory.get(item, 0)
        inventory[item] = max(0, current - qty)
        if inventory[item] == 0:
            inventory.pop(item)
        return reply("USE_FROM_INVENTORY", {"item": item, "quantity": qty},
                     f"Got it. You now have {inventory.get(item, 0)} {pluralize(qty, item)} left.")

    if match := re.search(r"(?:how many|how much|do i have any)\s+(.+)", lower):
        item = singularize(match.group(1))
        qty = inventory.get(item, 0)
        if qty > 0:
            return reply("CHECK_INVENTORY_ITEM", {"item": item},
                         f"You have {qty} {pluralize(qty, item)} left.")
        return reply("CHECK_INVENTORY_ITEM", {"item": item},
                     f"You don't have any {pluralize(2, item)} in your inventory.")

    return reply("UNKNOWN", {}, "Sorry, I didn’t understand that.")


def reply(intent: str, params: dict, text: str):
    return {
        "intent": intent,
        "parameters": params,
        "fulfillment_text": text
    }


def pluralize(qty: int, word: str):
    return word if qty == 1 else (word if word.endswith("s") else word + "s")


def singularize(word: str):
    return word.rstrip("s")
