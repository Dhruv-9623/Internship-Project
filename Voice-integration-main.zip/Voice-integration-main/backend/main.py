from fastapi import FastAPI
from pydantic import BaseModel
from commands import process_voice_command

app = FastAPI()

class VoiceCommand(BaseModel):
    text: str

@app.post("/process-command")
def process(cmd: VoiceCommand):
    return process_voice_command(cmd.text)
