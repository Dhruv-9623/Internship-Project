package com.example.voiceassistantapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import com.example.voiceassistantapp.ui.ChatScreen
import com.example.voiceassistantapp.ui.theme.VoiceAssistantAppTheme
import java.util.*

class MainActivity : ComponentActivity() {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var speechIntent: Intent
    private lateinit var textToSpeech: TextToSpeech
    private val viewModel: VoiceViewModel by viewModels()
    private var isSpeaking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setupTextToSpeech()
        setupSpeechRecognizer()

        setContent {
            VoiceAssistantAppTheme {
                // ✅ Speak any new bot reply via TTS
                LaunchedEffect(viewModel.textToSpeak.value) {
                    viewModel.textToSpeak.value?.let { text ->
                        speak(text)
                    }
                }

                // ✅ Always use ChatScreen
                ChatScreen(
                    userMessages = viewModel.userMessagesState.value,
                    botReplies = viewModel.botRepliesState.value,
                    isHelpVisible = viewModel.isHelpVisibleState.value,
                    recipeSteps = viewModel.recipeStepsState,
                    currentStep = viewModel.currentStepState.intValue,
                    onMicClick = { startListening() }
                )
            }
        }
    }

    private fun setupTextToSpeech() {
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech.language = Locale.US
            } else {
                Toast.makeText(this, "TTS initialization failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun speak(text: String) {
        isSpeaking = true
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utteranceId")
        Handler(Looper.getMainLooper()).postDelayed({
            isSpeaking = false
        }, 2000)
    }

    private fun setupSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        speechRecognizer.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = matches?.get(0) ?: return

                viewModel.sendVoiceCommandToApi(spoken)  // <- pass directly
                textToSpeech.speak("Processing: $spoken", TextToSpeech.QUEUE_FLUSH, null, null)
            }


            override fun onReadyForSpeech(params: Bundle?) {
                viewModel.isListeningState.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                viewModel.isListeningState.value = false
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startListening() {
        if (!isSpeaking) {
            // ❌ DON’T wipe recognizedTextState here!
            viewModel.isListeningState.value = true
            speechRecognizer.startListening(speechIntent)
        }
    }

    override fun onDestroy() {
        textToSpeech.stop()
        textToSpeech.shutdown()
        super.onDestroy()
    }
}
