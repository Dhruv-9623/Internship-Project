package com.example.voiceassistantapp.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    val api: VoiceApi by lazy {
        Retrofit.Builder()
            .baseUrl("http://10.0.2.2:8000/") // <-- use 10.0.2.2 to reach localhost from emulator
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(VoiceApi::class.java)
    }
}