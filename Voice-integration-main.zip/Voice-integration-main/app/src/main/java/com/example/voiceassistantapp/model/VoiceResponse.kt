package com.example.voiceassistantapp.model

data class VoiceResponse(
    val intent: String,
    val parameters: Map<String, Any>,
    val fulfillment_text: String
)