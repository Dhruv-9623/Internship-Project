package com.example.voiceassistantapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ChatDisplay(userMessage: String, botReply: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        if (userMessage.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Text(
                    text = userMessage,
                    color = Color.White,
                    modifier = Modifier
                        .background(color = Color(0xFF1976D2), shape = RoundedCornerShape(12.dp))
                        .padding(12.dp)
                        .widthIn(max = 280.dp),

                )
            }
        }

        if (botReply.isNotBlank()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start
            ) {
                Text(
                    text = botReply,
                    color = Color.Black,
                    modifier = Modifier
                        .background(color = Color(0xFFEEEEEE), shape = RoundedCornerShape(12.dp))
                        .padding(12.dp)
                        .widthIn(max = 280.dp)
                )
            }
        }
    }
}