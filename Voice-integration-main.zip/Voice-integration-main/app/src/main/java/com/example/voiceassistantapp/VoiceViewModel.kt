package com.example.voiceassistantapp

import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.example.voiceassistantapp.api.RetrofitClient
import com.example.voiceassistantapp.model.VoiceRequest
import com.example.voiceassistantapp.model.VoiceResponse
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.Locale
import kotlin.math.max
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import androidx.compose.foundation.lazy.LazyListState
import kotlinx.coroutines.withContext

class VoiceViewModel : ViewModel() {

    val recognizedTextState = mutableStateOf<List<String>>(emptyList())
    val spokenReplyState = mutableStateOf<List<String>>(emptyList())
    val isListeningState = mutableStateOf(false)
    val textToSpeak = mutableStateOf<String?>(null)
    val recipeStepsState = mutableStateListOf<String>()
    val currentStepState = mutableIntStateOf(-1)
    val isHelpVisibleState = mutableStateOf(false)

    val recipeListScrollState = LazyListState()

    val userMessagesState = recognizedTextState
    val botRepliesState = spokenReplyState

    private val eggOmeletRecipe = listOf(
        "Crack 3 eggs into a bowl and whisk them with a fork until well blended. This takes about 30 seconds.",
        "Add a pinch of salt and pepper to the eggs for seasoning.",
        "Heat a non-stick skillet over medium heat and melt 1 tablespoon of butter. This takes about 1 minute.",
        "Pour the eggs into the skillet and let them cook undisturbed for about 2 minutes until the edges start to set.",
        "Use a spatula to gently lift the edges, allowing uncooked egg to flow underneath. Cook for another 1-2 minutes.",
        "When the omelet is mostly set but slightly runny on top, add fillings like cheese or ham if desired.",
        "Fold the omelet in half and cook for another 30 seconds to 1 minute until fully set.",
        "Slide the omelet onto a plate and serve immediately."
    )

    private var currentStep = -1
    private val inventory = mutableMapOf<String, Int>()

    fun processVoiceCommand(command: String) {
        recognizedTextState.value = recognizedTextState.value + command
        isHelpVisibleState.value = false

        val lower = command.lowercase(Locale.getDefault())
        val addRegex = Regex("""add (.+)""")
        val usedRegex = Regex("""use (.+)""")
        val checkRegex = Regex("""(?:how many|how much|do I have any)\s+(.+)""")

        val jsonReply: String = when {
            "help" in lower || "what can you do" in lower -> {
                isHelpVisibleState.value = true
                val helpText = """
                    Here are some things you can ask me to do:

                    Recipe Commands:
                    • "Start an egg omelet"
                    • "Next or previous step"
                    • "Stop recipe"

                    Inventory Commands:
                    • "Add 5 apples"
                    • "Use 2 apples"
                    • "How many apples do I have?"
                    • "Show inventory"
                """.trimIndent()
                createJsonReply("SHOW_HELP", JSONObject(), helpText)
            }

            lower.contains("start") && (lower.contains("egg") || lower.contains("omelet")) -> {
                currentStep = 0
                val params = JSONObject().put("recipe_name", "egg_omelet")
                createJsonReply("START_RECIPE", params, eggOmeletRecipe[currentStep])
            }

            "exit recipe" in lower || "stop recipe" in lower || "end recipe" in lower -> {
                currentStep = -1
                createJsonReply("STOP_RECIPE", JSONObject(), "Okay, exiting the recipe.")
            }

            "what's in my inventory" in lower || "show inventory" in lower -> {
                val fulfillmentText = if (inventory.isEmpty()) {
                    "Your inventory is empty."
                } else {
                    inventory.entries.joinToString("\n") { (item, qty) -> "• $qty ${pluralize(qty, item)}" }
                        .let { "Here's what's in your inventory:\n$it" }
                }
                createJsonReply("SHOW_INVENTORY", JSONObject(), fulfillmentText)
            }

            addRegex.containsMatchIn(lower) -> {
                val (payload) = addRegex.find(lower)!!.destructured
                parseAndModifyInventory(payload, isAdding = true)
            }

            usedRegex.containsMatchIn(lower) -> {
                val (payload) = usedRegex.find(lower)!!.destructured
                parseAndModifyInventory(payload, isAdding = false)
            }

            checkRegex.containsMatchIn(lower) -> {
                val (item) = checkRegex.find(lower)!!.destructured
                val singularItem = singularize(item.trim())
                val count = inventory.getOrDefault(singularItem, 0)
                val fulfillmentText = if (count > 0) {
                    "You have $count ${pluralize(count, singularItem)} left."
                } else {
                    "You don't have any ${pluralize(2, singularItem)} in your inventory."
                }
                val params = JSONObject().put("item", singularItem)
                createJsonReply("CHECK_INVENTORY_ITEM", params, fulfillmentText)
            }

            "next step" in lower -> {
                val fulfillmentText = if (currentStep < eggOmeletRecipe.size - 1) {
                    currentStep++
                    eggOmeletRecipe[currentStep]
                } else {
                    "You're at the last step."
                }
                createJsonReply("NAVIGATE_RECIPE", JSONObject().put("direction", "next"), fulfillmentText)
            }

            "previous step" in lower || "go back" in lower -> {
                val fulfillmentText = if (currentStep > 0) {
                    currentStep--
                    "Okay, going back. The previous step was: ${eggOmeletRecipe[currentStep]}"
                } else {
                    "You're at the first step."
                }
                createJsonReply("NAVIGATE_RECIPE", JSONObject().put("direction", "previous"), fulfillmentText)
            }

            else -> createJsonReply("UNKNOWN", JSONObject(), "Sorry, I didn’t understand that.")
        }

        val responseJson = JSONObject(jsonReply)
        val fulfillmentText = responseJson.getString("fulfillment_text")

        spokenReplyState.value = spokenReplyState.value + fulfillmentText
        textToSpeak.value = fulfillmentText

        when (responseJson.getString("intent")) {
            "START_RECIPE" -> {
                recipeStepsState.clear()
                recipeStepsState.addAll(eggOmeletRecipe)
                currentStepState.intValue = currentStep
            }

            "STOP_RECIPE" -> {
                recipeStepsState.clear()
                currentStepState.intValue = -1
            }

            "NAVIGATE_RECIPE" -> {
                currentStepState.intValue = currentStep
            }
        }
    }

    fun onFinishedSpeaking() {
        textToSpeak.value = null
    }

    fun sendVoiceCommandToApi(command: String) {
        // This shows user's message instantly
        userMessagesState.value = userMessagesState.value + command

        val request = VoiceRequest(command)

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitClient.api.sendVoiceCommand(request)
                val reply = response.fulfillment_text ?: "No reply received."

                withContext(Dispatchers.Main) {
                    val currentSpokenReplies = spokenReplyState.value.toList()
                    val currentBotReplies = botRepliesState.value.toList()

                    spokenReplyState.value = currentSpokenReplies + reply
                    botRepliesState.value = currentBotReplies + reply
                    textToSpeak.value = reply
                }


            } catch (e: Exception) {
                val errorMsg = "Network error: ${e.message}"

                withContext(Dispatchers.Main) {
                    spokenReplyState.value = spokenReplyState.value + errorMsg
                    botRepliesState.value = botRepliesState.value + errorMsg
                }
            }
        }
    }



    private fun createJsonReply(intent: String, parameters: JSONObject, fulfillmentText: String): String {
        return JSONObject().apply {
            put("intent", intent)
            put("parameters", parameters)
            put("fulfillment_text", fulfillmentText)
        }.toString(2)
    }

    private fun parseAndModifyInventory(payload: String, isAdding: Boolean): String {
        val parts = payload.split(" ").toMutableList()
        if (parts.isEmpty()) return createJsonReply("ERROR", JSONObject().put("reason", "No payload"), "Sorry, I didn't catch that.")

        if (parts.size > 1 && (parts[0].lowercase() == "a" || parts[0].lowercase() == "an")) {
            parts.removeAt(0)
        }

        val qty = parseNumber(parts[0])
        val item = if (qty != 1 || parts[0].toIntOrNull() != null) parts.drop(1).joinToString(" ") else parts.joinToString(" ")
        if (item.isBlank()) return createJsonReply("ERROR", JSONObject().put("reason", "No item specified"), "What item should I modify?")

        val singularItem = singularize(item.trim())
        val current = inventory.getOrDefault(singularItem, 0)
        val newQty = if (isAdding) current + qty else max(0, current - qty)

        if (newQty > 0) inventory[singularItem] = newQty else inventory.remove(singularItem)

        val fulfillmentText = if (isAdding) {
            "Okay, I've added $qty ${pluralize(qty, singularItem)} to your inventory."
        } else {
            "Got it. You now have $newQty ${pluralize(newQty, singularItem)} left."
        }

        return createJsonReply(
            if (isAdding) "ADD_TO_INVENTORY" else "USE_FROM_INVENTORY",
            JSONObject().put("item", singularItem).put("quantity", qty),
            fulfillmentText
        )
    }

    private fun parseNumber(input: String): Int = when (input.lowercase()) {
        "a", "an", "one" -> 1
        "two", "couple", "a couple" -> 2
        "three" -> 3
        "four" -> 4
        "five" -> 5
        "six" -> 6
        "seven" -> 7
        "eight" -> 8
        "nine" -> 9
        "ten" -> 10
        "dozen" -> 12
        else -> input.toIntOrNull() ?: 1
    }

    private fun pluralize(count: Int, word: String): String {
        return if (count == 1 || word.endsWith("s", ignoreCase = true)) word else "${word}s"
    }

    private fun singularize(word: String): String {
        return if (word.endsWith("s", ignoreCase = true) && !word.endsWith("ss", ignoreCase = true)) word.dropLast(1) else word
    }
}
