package com.example.voiceassistantapp.api

import com.example.voiceassistantapp.model.VoiceRequest
import com.example.voiceassistantapp.model.VoiceResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST

interface VoiceApi {
    @POST("/process-command")
    suspend fun sendVoiceCommand(@Body request: VoiceRequest): VoiceResponse
}