package com.example.voiceassistantapp.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RecipeStepsList(
    listState: LazyListState,
    steps: List<String>,
    currentStep: Int
) {
    LazyColumn(
        state = listState,
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        itemsIndexed(steps) { index, step ->
            val isCurrent = index == currentStep
            Text(
                text = "${index + 1}. $step",
                color = if (isCurrent) MaterialTheme.colorScheme.primary else Color.Unspecified,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )
        }
    }
}
