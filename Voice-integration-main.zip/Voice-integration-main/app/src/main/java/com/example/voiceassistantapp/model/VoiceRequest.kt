package com.example.voiceassistantapp.model

data class VoiceRequest(val text: String)