# 🍳 MealLens Voice Assistant

An Android app that guides users through recipes via voice commands and manages grocery inventory.

[![Kotlin](https://img.shields.io/badge/Kotlin-1.9.0-purple.svg)](https://kotlinlang.org)
[![Compose](https://img.shields.io/badge/Jetpack%20Compose-1.5.0-blue.svg)](https://developer.android.com/jetpack/compose)

## Features ✨
- **Voice-controlled recipes**:
  - _"Start an egg omelet"_ → Step-by-step instructions
  - _"Next step"_ / _"Previous step"_
- **Smart inventory tracking**:
  - _"Add 3 tomatoes"_ / _"Use 2 eggs"_
  - _"How many apples do I have?"_
- **Help menu**: _"What can you do?"_ lists all commands

## Tech Stack 🛠️
- **Kotlin** + **Jetpack Compose** (UI)
- Android `SpeechRecognizer` & `TextToSpeech` APIs
- MVVM Architecture
- Retrofit (for future API expansion)

## Architecture
```mermaid
flowchart TD
    A[MainActivity] -->|Voice Input| B[VoiceViewModel]
    B -->|State| C[RecipeStepsList]
    B -->|TTS| A
    B -->|API Calls| D[RetrofitClient]

```
## How to Run
* Clone the repo:
  `git clone https://github.com/[actual_repo_link_here].git`
* Open in Android Studio (Electric Eel or newer)
* Build & run on an Android device/emulator (API 26+)
* Setup Virtual Env [How to setup virtual env](https://tausifzmn.notion.site/Updates-and-how-to-set-up-virtual-env-before-running-app-to-host-backend-23ab691a2b5d80728d4cd1f336049971)

## Sample Commands 🎤
```
"Start an egg omelet"  // Begins recipe
"Add 5 potatoes"       // Updates inventory
"What's in my fridge?" // Lists items
"Help"                 // Shows command list
```
Commands in Detail [Notion Link](https://tausifzmn.notion.site/Commands-for-VI-22fb691a2b5d80ef8223c9b43ef85d78)


## Future Work 🔮
* Integrate Spoonacular API for more recipes

* Add multilingual support

* Implement meal planning


## License 📄
MIT License - See [LICENSE]()